#__init__.py

default_app_config = 'login.apps.YourAppNameConfig' 